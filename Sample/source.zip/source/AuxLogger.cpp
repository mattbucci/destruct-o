#include "stdafx.h"
#include "AuxLogger.h"

#ifdef __ANDROID__
AuxLogging AuxLogger;
#endif